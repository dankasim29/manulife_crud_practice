import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type ClientUserDataDocument = ClientUserData & Document;

@Schema()
export class ClientUserData {
  @Prop()
  fname: string;
  @Prop()
  mname: string;
  @Prop()
  lname: string;
  @Prop()
  ip: string;
  @Prop()
  number: string;
  @Prop()
  dataLocationInfo: string;
}

export const ClientUserDataSchema =
  SchemaFactory.createForClass(ClientUserData);
