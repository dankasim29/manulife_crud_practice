import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Param,
  Post,
  Put,
  Res,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express/multer';
import { XcelService } from '../xcel/xcel.service';
import { ClientUserData } from './client.model';
import { ClientService } from './client.service';

@Controller('client')
export class ClientController {
  constructor(
    private readonly clientService: ClientService,
    private readonly xcelservice: XcelService,
  ) {}

  @Post()
  async createBook(@Res() response, @Body() book: ClientUserData) {
    const newClient = await this.clientService.create(book);
    return response.status(HttpStatus.CREATED).json({
      newClient,
    });
  }

  @Get()
  async fetchAll(@Res() response) {
    const client = await this.clientService.readAll();
    return response.status(HttpStatus.OK).json({
      client,
    });
  }

  @Get('/:id')
  async findById(@Res() response, @Param('id') id) {
    const book = await this.clientService.readById(id);
    return response.status(HttpStatus.OK).json({
      book,
    });
  }

  @Put('/:id')
  async update(@Res() response, @Param('id') id, @Body() book: ClientUserData) {
    const updatedAvengers = await this.clientService.update(id, book);
    return response.status(HttpStatus.OK).json({
      updatedAvengers,
    });
  }

  @Delete('/:id')
  async delete(@Res() response, @Param('id') id) {
    const deletedAvengers = await this.clientService.delete(id);
    return response.status(HttpStatus.OK).json({
      deletedAvengers,
    });
  }

  @Post('upload')
  @UseInterceptors(FileInterceptor('file'))
  async uploadFile(@UploadedFile() file: Express.Multer.File) {
    await this.xcelservice.readyFile(file.buffer);
  }
}
