import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { ClientUserData, ClientUserDataDocument } from './client.model';
import { Model } from 'mongoose';

@Injectable()
export class ClientService {
  constructor(
    @InjectModel(ClientUserData.name)
    private clientModels: Model<ClientUserDataDocument>,
  ) {}

  async create(book: ClientUserData): Promise<ClientUserData> {
    const newBook = new this.clientModels(book);
    return newBook.save();
  }

  async readAll(): Promise<ClientUserData[]> {
    return await this.clientModels.find().exec();
  }

  async readById(id): Promise<ClientUserData> {
    return await this.clientModels.findById(id).exec();
  }

  async update(id, book: ClientUserData): Promise<ClientUserData> {
    return await this.clientModels.findByIdAndUpdate(id, book, { new: true });
  }

  async delete(id): Promise<any> {
    return await this.clientModels.findByIdAndRemove(id);
  }
  
}
