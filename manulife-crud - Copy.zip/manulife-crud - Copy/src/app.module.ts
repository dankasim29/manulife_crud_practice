import { HttpModule, HttpService, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ClientController } from './client/client.controller';
import { ClientUserData, ClientUserDataSchema } from './client/client.model';
import { ClientService } from './client/client.service';
import { XcelService } from './xcel/xcel.service';

@Module({
  imports: [
    HttpModule,
    MongooseModule.forRoot('mongodb://localhost/demo'),
    MongooseModule.forFeature([
      { name: ClientUserData.name, schema: ClientUserDataSchema },
    ]),
  ],
  controllers: [ClientController],
  providers: [ClientService, XcelService],
})
export class AppModule {}
