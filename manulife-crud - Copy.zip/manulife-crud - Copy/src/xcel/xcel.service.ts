import { Logger, Injectable, ConsoleLogger, HttpService } from '@nestjs/common';
import { assert } from 'console';
import { ReadStream } from 'fs';
import { AxiosResponse } from 'axios'
import { Observable } from 'rxjs'
import { arrayBuffer } from 'stream/consumers';
import * as xlsx from 'xlsx';
import { WorkBook, WorkSheet } from 'xlsx';
import { ClientService } from '../client/client.service';

@Injectable()
export class XcelService {
  private readonly logger = new Logger(XcelService.name);
  constructor(
    private readonly clientService: ClientService,
    private readonly http: HttpService,
  ) {}

  async readyFile(test: any): Promise<any> {
    try {
      const wb = xlsx.read(test, { type: 'buffer' });

      const sheet: WorkSheet = wb.Sheets[wb.SheetNames[0]];
      const range = xlsx.utils.decode_range(sheet['!ref']);


      for (let R = range.s.r; R <= range.e.r; ++R) {
        if (R === 0 || !sheet[xlsx.utils.encode_cell({ c: 0, r: R })]) {
          continue;
        }
        let col = 0;
        const temp = {
          fname: sheet[xlsx.utils.encode_cell({ c: col++, r: R })]?.v,
          mname: sheet[xlsx.utils.encode_cell({ c: col++, r: R })]?.v,
          lname: sheet[xlsx.utils.encode_cell({ c: col++, r: R })]?.v,
          ip: sheet[xlsx.utils.encode_cell({ c: col++, r: R })]?.v,
          number: sheet[xlsx.utils.encode_cell({ c: col++, r: R })]?.v,
          dataLocationInfo: null,
        };
        const ipDetails = await this.getIpInforation(temp.ip);
        temp.dataLocationInfo = JSON.stringify(ipDetails);
        console.log(temp);
        await this.clientService.create(temp);
      }

      return 0;
    } catch (error) {
      this.logger.log(error);
      return 1;
    }
  }
  async getIpInforation(ip: string): Promise<Observable<AxiosResponse<any>>> {
    //  return this.http.get('http://ip-api.com/json/' + ip);
    const response = await this.http
      .get('http://ip-api.com/json/' + ip)
      .toPromise();
     return response.data;
  }
}
